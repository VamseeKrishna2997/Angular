# Syllabus

Week 1<br>
Front-End Javascript Frameworks: AngularJS Overview<br>

Full-Stack Web Development: The Big Picture<br>
Introduction to AngularJS<br>
Models, Views and Controllers<br>
Angular Filters<br>
Assignment: Introduction to AngularJS<br>

Week 2<br>
Task Runners, Angular Scope, Forms and Form Validation<br>

Web Tools: Grunt and Gulp<br>
Angular Scope<br>
Angular Forms and Form Validation<br>
Assignment: Angular Forms<br>

Week 3<br>
Single Page Applications<br>

Angular Factory, Service and Dependency Injection<br>
Angular Templates<br>
Angular ngRoute and Single Page Applications<br>
Angular UI-Router for Single Page Applications<br>
Assignment: Single Page Applications<br>

Week 4<br>
Client-Server Communication and Angular Testing<br>

Client-Server Communication<br>
Angular $http Service<br>
RESTful Services and Angular $resource<br>
Angular Testing<br>
Web Tools: Yo and Yeoman<br>
Assignment: Client-Server Communication<br>
